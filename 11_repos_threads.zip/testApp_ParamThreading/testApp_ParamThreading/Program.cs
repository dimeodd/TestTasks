﻿using System;
using System.Threading;
using static System.Console;

namespace testApp_ParamThreading
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread secTread = new Thread(new ParameterizedThreadStart(Count));
            secTread.Start(1);

            for (int i = 1; i <= 9; i++)
            {
                WriteLine($"First Thread: {i * i}");
                Thread.Sleep(300);
            }

            secTread.Join();

            ReadKey();

        }

        static void Count(object value)
        {
            int x = (int) value;

            for (int i = 1; i <= 9; i++)
            {
                WriteLine($"Second Thread: {Math.Pow(x, i)}");
                Thread.Sleep(400);
            }
        }
    }
}
