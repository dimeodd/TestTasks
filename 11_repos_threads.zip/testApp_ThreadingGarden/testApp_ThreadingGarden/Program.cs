﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace testApp_ThreadingGarden
{
    class Program
    {
        static char[,] garden = new char[50, 20];

        static bool isRunning = true;

        static void Main(string[] args)
        {
            Thread g1 = new Thread(new ThreadStart(Gardener1));
            Thread g2 = new Thread(new ThreadStart(Gardener2));
            g1.Start();
            g2.Start();

            Thread info = new Thread(new ThreadStart(DrawGarden));
            info.Start();

            g1.Join();
            g2.Join();

            isRunning = false;

            Console.ReadLine();
        }

        static void DrawGarden()
        {
            Console.BufferWidth = 120;
            Console.BufferHeight = 150;
            while (isRunning)
            {
                int width = (int)garden.GetLongLength(0);
                int height = garden.Length / width;



                var text = string.Empty;
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        text += garden[x, y];
                    }
                    text += "\n";
                }
                Console.Clear();
                Console.WriteLine(text);
                Thread.Sleep(50);
            }
            Console.Write("\n calc complete!");
        }

        static void Gardener1()
        {
            int width = (int)garden.GetLongLength(0);
            int height = garden.Length / width;

            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                {
                    if (garden[x, y] != 0) continue;

                    garden[x, y] = 'I';

                    Thread.Sleep(50);
                }
        }

        static void Gardener2()
        {
            int width = (int)garden.GetLongLength(0);
            int height = garden.Length / width;

            for (int y = height - 1; y >= 0; y--)
                for (int x = width - 1; x >= 0; x--)
                {
                    if (garden[x, y] != 0) continue;

                    garden[x, y] = '#';

                    Thread.Sleep(50);
                }
        }
    }

}
