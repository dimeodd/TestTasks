﻿using System;
using System.Threading;
using static System.Console;

namespace testApp_treading
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread secTread = new Thread(new ThreadStart(Count));
            secTread.Start();

            for (int i = 1; i <= 9; i++)
            {
                WriteLine($"First Thread: {i * i}");
                Thread.Sleep(300);
            }

            secTread.Join();

            ReadKey();
            
        }

        static  void Count()
        {
            for (int i = 1; i <= 9; i++)
            {
                WriteLine($"Second Thread: {i * i}");
                Thread.Sleep(400);
            }
        }
    }
}
