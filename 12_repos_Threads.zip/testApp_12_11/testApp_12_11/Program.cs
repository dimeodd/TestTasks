﻿using System;
using System.Threading;

namespace testApp_TreadingSemaphore
{
    class Program
    {
        const int capacity = 5;

        static Semaphore sem = new Semaphore(0, capacity);
        static object locker = new object();

        static void Main(string[] args)
        {
            Console.WriteLine("Readers creating");

            new Writer(0);

            for (int i = 0; i < 10; i++)
            {
                new Reader(i + 1);
            }
            new Writer(1);
            new Writer(2);

            Thread.Sleep(1000);

            Console.WriteLine("Library open");
            sem.Release(capacity);

            //Thread.Sleep(500);
            //Console.WriteLine("Close 2 seats");
            //sem.WaitOne();
            //sem.WaitOne();

            Console.ReadLine();
        }

        class Reader
        {
            int ticketsLeft = 3;

            public Reader(int i)
            {
                var thisThread = new Thread(Read);
                thisThread.Name = "Reader " + i;
                thisThread.Start();
            }

            void Read()
            {
                while (ticketsLeft > 0)
                {
                    lock (locker)
                    {
                        sem.WaitOne();
                    }

                    Console.WriteLine($"{Thread.CurrentThread.Name}, in");
                    ticketsLeft--;

                    Console.WriteLine($"{Thread.CurrentThread.Name}, read");
                    Thread.Sleep(1000);

                    Console.WriteLine($"{Thread.CurrentThread.Name}, out");
                    sem.Release();

                    Thread.Sleep(1000);
                }
            }
        }

        class Writer
        {
            public Writer(int i)
            {
                var thisThread = new Thread(Write);
                thisThread.Name = "Writer " + i;
                thisThread.Start();
            }

            void Write()
            {
                lock (locker)
                {
                    // занять все свободные места в зале
                    for (int i = 0; i < capacity; i++)
                    {
                        sem.WaitOne();
                    }
                }

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{Thread.CurrentThread.Name}, in");

                Console.WriteLine($"{Thread.CurrentThread.Name}, write some data");
                Thread.Sleep(1000);

                Console.WriteLine($"{Thread.CurrentThread.Name}, out");
                Console.ForegroundColor = ConsoleColor.White;

                // освободить зал
                sem.Release(capacity);
            }
        }
    }
}

