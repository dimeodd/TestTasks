﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace testApp_12_12
{
    class Program
    {
        static List<ProtectedString> database = new List<ProtectedString>();

        static Dictionary<string, string> buffer = new Dictionary<string, string>();

        static object lockDatabase = new object();
        static object lockDictonary = new object();

        static void Main(string[] args)
        {
            new Writer("Some data want link me");

            Thread.Sleep(100);

            new Reader("Some");
            new Reader("Some");
            new Reader("ome");

            Thread.Sleep(100);

            new Reader("Some");

            Console.ReadLine();
        }

        class Writer
        {
            string value = null;

            public Writer(string value)
            {
                this.value = value;

                Thread writer = new Thread(Write);
                writer.Start();
            }

            void Write()
            {
                lock (lockDatabase)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Database locked");

                    var newData = new ProtectedString(value);
                    database.Add(newData);

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Database unlocked");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }

        class Reader
        {
            string value = null;

            /// <summary>
            /// ищет первый элемент содержащий "value" 
            /// </summary>
            public Reader(string value)
            {
                this.value = value;

                Thread writer = new Thread(Read);
                writer.Start();
            }

            void Read()
            {
                string readData = null;


                if (buffer.TryGetValue(value, out var data))
                {
                    readData = data;
                }
                else
                {
                    lock (lockDictonary)
                    {
                        if (buffer.ContainsKey(value))
                        {
                            readData = buffer[value];
                        }
                        else
                        {
                            lock (lockDatabase)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Database locked");

                                readData = database.Find((x) => x.Data.Contains(value))?.Data ?? "NaN";

                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine($"searching \"{value}\" in Database");


                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Database unlocked");
                                Console.ForegroundColor = ConsoleColor.White;
                            }

                            if (readData != "NaN")
                            {
                                buffer.Add(value, readData);
                            }
                        }
                    }
                }

                Console.WriteLine("key: {0}; data: {1}",
                    value,
                    readData
                    );

            }
        }

        class ProtectedString
        {
            public readonly string Data;

            public ProtectedString(string data)
            {
                Data = data;
            }
        }
    }
}
