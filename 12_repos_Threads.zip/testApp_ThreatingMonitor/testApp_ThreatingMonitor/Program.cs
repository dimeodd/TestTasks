﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using static System.Console;

namespace testApp_ThreadingSync
{
    class Program
    {
        static int x = 0;

        static object token = new object();

        static void Main(string[] args)
        {
            for (int i = 0; i < 9; i++)
            {
                Thread myThread = new Thread(Count);
                myThread.Name = "Thread: " + i;

                myThread.Start();
            }

            ReadLine();
        }

        static void Count()
        {
            bool isLock = false;

            Monitor.Enter(token, ref isLock);
            x = 1;
            for (int i = 0; i < 9; i++)
            {
                WriteLine("{0}; {1}", Thread.CurrentThread.Name, x);
                x++;

                Thread.Sleep(100);
            }
            Monitor.Exit(token);
        }
    }
}
