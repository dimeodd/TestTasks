﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace testApp_Timer
{
    class Program
    {
        static void Main(string[] args)
        {
            TimerCallback a = new TimerCallback(WriteWeatherStatus);
            Timer timer = new Timer(a, null, 0, 10_000);

            Console.ReadLine();
        }

        static void WriteWeatherStatus(Object stateInfo)
        {
            Console.WriteLine("{0:h:mm:ss} weather is fine", DateTime.Now);
        }
    }
}
