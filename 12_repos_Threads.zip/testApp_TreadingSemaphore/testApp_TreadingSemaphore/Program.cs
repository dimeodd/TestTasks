﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace testApp_TreadingSemaphore
{
    class Program
    {

        static Semaphore sem = new Semaphore(0, 3);            

        static void Main(string[] args)
        {
            Console.WriteLine("Readers creating");

            for (int i =0; i < 3; i++)
            {
                new Reader(i + 1);
            }

            Thread.Sleep(1000);

            Console.WriteLine("Library open");
            sem.Release(3);
            
            //Thread.Sleep(500);
            //Console.WriteLine("Close 2 seats");
            //sem.WaitOne();
            //sem.WaitOne();

            Console.ReadLine();
        }

        class Reader
        {
            int ticketsLeft = 3;

            public Reader(int i)
            {
                var thisThread = new Thread(Read);
                thisThread.Name = "Reader " + i;
                thisThread.Start();
            }

            void Read()
            {
                while(ticketsLeft>0)
                {
                    sem.WaitOne();

                    Console.WriteLine($"{Thread.CurrentThread.Name}, in");
                    ticketsLeft--;

                    Console.WriteLine($"{Thread.CurrentThread.Name}, read");
                    Thread.Sleep(1000);

                    Console.WriteLine($"{Thread.CurrentThread.Name}, out");
                    sem.Release();

                    Thread.Sleep(1000);
                }
            }
        }
    }
}
