﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp_13_Matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            var m1 = FillMatrix(new Matrix(10, 5));
            var m2 = FillMatrix(new Matrix(10, 5));

            Console.WriteLine("m1");
            Console.WriteLine(m1);
            Console.WriteLine("m2");
            Console.WriteLine(m2);

            var m3 = m1 + m2;

            Console.WriteLine("m3");
            Console.WriteLine(m3);
            Console.ReadKey();
        }

        static Matrix FillMatrix(Matrix m)
        {
            Parallel.For(0, m.width, (x) =>
            {
                Parallel.For(0, m.height, (y) =>
                {
                    m[x, y] = x;
                });
            });
            return m;
        }
    }

    class Matrix
    {
        int[,] data;

        public readonly int height;
        public readonly int width;

        public Matrix(int width, int height)
        {
            this.width = width;
            this.height = height;
            data = new int[width, height];
        }

        public int this[int x, int y]
        {
            get => data[x, y];
            set => data[x, y] = value;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    sb.Append(data[x, y]);

                    if (x != width - 1)
                        sb.Append("| ");
                    else
                        sb.Append("\n");
                }
            }

            return sb.ToString();
        }

        public static Matrix operator +(Matrix m1, Matrix m2)
        {
            int width = Math.Max(m1.width, m2.width);
            int height = Math.Max(m1.height, m2.height);

            Matrix result = new Matrix(width, height);

            Parallel.For(0, width, (x) =>
            {
                Parallel.For(0, height, (y) =>
                {
                    try
                    {
                        result[x, y] += m1[x, y];
                    }
                    catch { }
                    try
                    {
                        result[x, y] += m2[x, y];
                    }
                    catch { }
                });
            });

            return result;
        }

    }
}
