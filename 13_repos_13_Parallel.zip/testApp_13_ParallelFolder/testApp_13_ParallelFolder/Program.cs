﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using PathGiver;
using System.IO;

namespace testApp_13_ParallelFolder
{
    class Program
    {
        static object lockerSize = new object();
        static object lockerErrors = new object();
        static Int64 size;
        static Int64 errors;

        static void Main(string[] args)
        {
            string path = DataTools.GetFolderPath();

            Thread display = new Thread(new ParameterizedThreadStart(RefrashStatus));
            display.Start(path);

            getDirectorySize(new DirectoryInfo(path));

            display.Abort();

            Console.Clear();
            Console.WriteLine("Selected: " + path);
            Console.WriteLine("Complete calc!");
            Console.WriteLine("Size: {0} bytes", size);
            Console.WriteLine("Size: {0:N2} GB", (Double)size / Math.Pow(2, 30));
            Console.WriteLine("Erros: {0}", errors);

            Console.ReadLine();
        }

        static void RefrashStatus(object inString)
        {
            string path = (string)inString;
            byte counter = 0;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Selected: " + path);
                Console.Write("Calculating");

                for(int i = 0; i < counter; i++)
                {
                    Console.Write('.');
                }

                if (counter >= 3)
                    counter = 0;
                else
                    counter++;

                Thread.Sleep(500);
            }
        }

       static  void getDirectorySize(DirectoryInfo dirInfo)
       {

            var files = dirInfo.GetFiles();
            var dirs = dirInfo.GetDirectories();

            Parallel.ForEach(files, (fileInfo) =>
             {
                 lock (lockerSize)
                 {
                     size += fileInfo.Length;
                 }
            });

            Parallel.ForEach(dirs, (x) =>
            {
                try
                {
                    getDirectorySize(x);
                }
                catch
                {
                    lock (lockerSize)
                    {
                        errors++;
                    }
                }
            });
        }
    }
}
