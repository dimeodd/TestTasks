﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;

namespace testApp_13_Parrallel_invoke
{
    class Program
    {
        static void Main(string[] args)
        {
            Parallel.Invoke(Method, Method, () => Func(3),() => Func(8));

            ReadLine();
        }

        static void Method()
        {
            WriteLine($"Method {Task.CurrentId} start!");
            Thread.Sleep(1000);
            WriteLine($"Method {Task.CurrentId} end!");
        }

        static void Func(int value)
        {
            string taskName = $"Func {Task.CurrentId}: ";

            WriteLine(taskName + "start!");
            WriteLine(taskName +value+ "^2 = "+ value * value);

            Thread.Sleep(1000);

            WriteLine(taskName + "end!");
        }
    }
}
