﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp_13_InnerTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Task taskOut = Task.Run(() =>
            {
                Console.WriteLine("taskOut start!");
                Task taskIn = Task.Run(() => Console.WriteLine("taskIn start!"));
                Console.WriteLine("taskOut complete!");
            });

            taskOut.Wait();

            Console.WriteLine("Main complete!");
            Console.ReadLine();
        }
    }
}
