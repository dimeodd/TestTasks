﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;


namespace testApp_13_multiTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Task[] array = new Task[10];
            int j = 0;
            for (int i = 0; i < array.Length; i++)
            {
                string a = i+" Start!";
                array[i] = Task.Factory.StartNew(() => WriteLine(a));
            }

            Task.WaitAll(array);

            WriteLine("Main Complete!");
            ReadKey();

        }

        static void Work(string name)
        {
            Thread.Sleep(1000);
            WriteLine(name + "; Complete!");
        }
    }
}

