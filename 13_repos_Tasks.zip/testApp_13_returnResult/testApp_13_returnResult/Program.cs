﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace testApp_13_returnResult
{
    class Program
    {
        static void Main(string[] args)
        {

            Task<double> task1 = new Task<double>(()=>HeavyMath(1000));
            task1.Start();
            Console.WriteLine("Main exist");
            
            Console.WriteLine("Result: "+task1.Result);
            Console.ReadKey();

        }

        static double HeavyMath(int x)
        {
            Console.WriteLine("Task start");

            double result = x;

            while (true)
            {
                Thread.Sleep(100);
                if (x <= 1)
                    break;
                result += x;
                x--;
            }

            Console.WriteLine("Task complete");

            return result;
        }
    }
}
