﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Task task1 = Task.Factory.StartNew(() => DoWork("startNew"));
            Task task2 = Task.Run(() => DoWork("theRun"));

            task1.Wait();
            task2.Wait();
            
            Console.WriteLine("Main Complete!");

            Console.ReadLine();
        }

        static void DoWork(string name)
        {
            Console.WriteLine(name + " start task");
            Thread.Sleep(1000);
            Console.WriteLine(name + " complete Work!");
        }
    }
}
