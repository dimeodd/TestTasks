﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using static System.Console;

namespace testApp_Threading_TaskContinue
{
    class Program
    {
        static void Main(string[] args)
        {
            Task task1 = new Task(() =>
            {
                WriteLine("task1 start by:" + Task.CurrentId);
                Thread.Sleep(1000);
                WriteLine("task1 complete");
            });

            Task task2 = task1.ContinueWith(Task2);

            task1.Start();

            ReadLine();
        }

        static void Task2(Task a)
        {
            WriteLine("task2 start by:"+Task.CurrentId);
            Thread.Sleep(1000);
            WriteLine("task2 complete");
        }
    }
}
