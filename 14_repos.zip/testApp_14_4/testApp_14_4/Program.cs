﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace testApp_14_4
{
    class Program
    {
        static void Main(string[] args)
        {
            FactorialAsync(5);
            FactorialAsync(7);

            Console.WriteLine("Введите число: ");
            int n = Int32.Parse(Console.ReadLine());
            Console.WriteLine($"Квадрат числа равен {n * n}");


            Console.ReadLine();
        }

        static async void FactorialAsync(int value)
        {
            Console.WriteLine("Начало метода FactorialAsync");
            await Task.Run(() => Factorial(value));
            Console.WriteLine("Конец метода FactorialAsync");
        }

        static void Factorial(int value)
        {
            int temp = value;

            for(int i = value-1; i > 0; i--)
            {
                value *= i;
            }

            Thread.Sleep(2000);

            Console.WriteLine($"Factorial {temp}: {value}");
        }
    }
}
