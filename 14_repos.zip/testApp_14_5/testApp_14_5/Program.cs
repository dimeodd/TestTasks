﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace testApp_14_5
{
    class Program
    {
        static void Main(string[] args)
        {

            WriteAsync();
            ReadAsync();

            Console.ReadLine();
        }

        static async void WriteAsync()
        {
            await Task.Run(() =>
            {
                try
                {
                    Console.WriteLine("Write Begin");

                    string text =
                    "stroke 1\n" +
                    "stroke 2 \n" +
                    "stroke 3 \n" +
                    "stroke 4";

                    using (FileStream fs = new FileStream("D:/text.txt", FileMode.Create))
                    {
                        var input = Encoding.Default.GetBytes(text);
                        fs.Write(input, 0, input.Length);
                    }

                    Console.WriteLine("Write Complete!");
                }
                catch
                {
                    Console.WriteLine("Write Error");
                    Thread.Sleep(100);
                    WriteAsync();
                }
            });
        }

        static async void ReadAsync()
        {
            await Task.Run(() =>
            {
                try
                {
                    Console.WriteLine("Read Begin");

                    using (FileStream fs = new FileStream("D:/text.txt", FileMode.Open))
                    {
                        byte[] output = new byte[fs.Length];
                        fs.Read(output, 0, output.Length);
                        string text = Encoding.Default.GetString(output);
                        Console.WriteLine(text);
                    }

                    Console.WriteLine("Read Complete!");
                }
                catch
                {
                    Console.WriteLine("Read Error");
                    Thread.Sleep(100);
                    ReadAsync();
                }
            });
        }
    }
}
