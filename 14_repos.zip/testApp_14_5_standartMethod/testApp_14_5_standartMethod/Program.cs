﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace testApp_14_5_standartMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteAcync();
            ReadAcync();

            Console.ReadLine();
        }

        static async void WriteAcync()
        {
            string text = "Съешь еще этих мягких французских булок";

            using (StreamWriter sw = new StreamWriter("D:/text.txt", false))
            {
                await sw.WriteAsync(text);
            }
        }

        static async void ReadAcync()
        {
            using (StreamReader sr = new StreamReader("D:/text.txt"))
            {
                string output = await sr.ReadLineAsync();
                Console.WriteLine(output);
            }
        }
    }
}
