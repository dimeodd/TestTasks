﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace testApp_14_7
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var t1 = Task.Run(() => Factorial(2));
            var t2 = Task.Run(() => Factorial(5));
            var t3 = Task.Run(() => Factorial(7));
            var t4 = Task.Run(() => Factorial(0));

            var a = Task.WhenAll(t1, t2, t3);

            Task<int[]> b = null;
            try
            {
                b = Task.WhenAll(t1, t2, t3, t4);

                Console.WriteLine(b.Result[0]);
                Console.WriteLine(b.Result[1]);
                Console.WriteLine(b.Result[2]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

                foreach (var item in b.Exception.InnerExceptions)
                {
                    Console.WriteLine(item.Message);
                }
            }

            Console.WriteLine();

            Console.WriteLine(a.Result[0]);
            Console.WriteLine(a.Result[1]);
            Console.WriteLine(a.Result[2]);

            Console.WriteLine();

            CancellationTokenSource cts = new CancellationTokenSource();

            FactorialAsyncToken(cts.Token);
            Thread.Sleep(1000);
            cts.Cancel();

            Console.WriteLine(await FactorialAsync(2));
            Console.WriteLine(await FactorialAsync(4));
            Console.WriteLine(await FactorialAsync(6));

            Console.ReadLine();
        }

        static async Task<int> FactorialAsync(int value)
        {
            return await Task.Run(() => Factorial(value));
        }

        static async void FactorialAsyncToken(CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                Console.WriteLine("Операция прервана");
                return;
            }

            Console.WriteLine(await FactorialAsync(7));

            if (token.IsCancellationRequested)
            {
                Console.WriteLine("Операция прервана");
                Console.WriteLine();
                return;
            }

            Console.WriteLine(await FactorialAsync(8));

            if (token.IsCancellationRequested)
            {
                Console.WriteLine("Операция прервана");
                return;
            }

            Console.WriteLine(await FactorialAsync(9));

        }

        static int Factorial(int value)
        {
            if (value < 1)
                throw new Exception($"Value {value} can't be less then 1");

            int temp = value;

            for (int i = value - 1; i > 0; i--)
            {
                value *= i;
            }

            Thread.Sleep(2000);
            return value;
        }
    }







}
