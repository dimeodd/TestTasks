﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp_17
{
    class Worker
    {
        public virtual int ID { get; set; }
        public virtual string Name { get; set; }
        public virtual string Login { get; set; }
        public virtual int Salary { get; set; }
        public virtual int Age { get; set; }
        public virtual DateTime Date { get; set; }

        public override string ToString()
        {
            return string.Format("{0}\t{1}\t$: {2}\t {3}\t {4}",
                          Name, Age, Salary, Login, Date);
        }
    }
}
