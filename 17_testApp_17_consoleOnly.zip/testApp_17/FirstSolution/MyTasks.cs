﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp_17
{
    static class MyTasks
    {

        static private Worker[] list = null;

        public static void Init(Worker[] workers)
        {
            list = workers;
        }

        static void DrawResults(IEnumerable data)
        {
            int count = 0;
            foreach (var wrk in data)
            {
                count++;
            }

            if (count > 0)
            {
                int i = 0;
                foreach (var wrk in data)
                {
                    i++;
                    Console.WriteLine(wrk);

                    if (i % 25 == 0)
                    {
                        Console.WriteLine($"\nList {i / 25}/{count / 25 + 1}");
                        Console.WriteLine("Press anykey to next");
                        Console.ReadKey();
                        Console.Clear();
                    }
                }
            }
            else
            {
                Console.WriteLine("Results not found");
            }
        }
        public delegate void TaslHandler();
        public static TaslHandler[] Task = new TaslHandler[]{
        delegate(){
                        Console.WriteLine("1)");
                        var customers = from c in list
                                        where c.Name == "браунулиус" || c.Name == "ангубуес" || c.Name == "ефринулиус"
                                        orderby c.Name
                                        select c;
                        DrawResults(customers);
                    }
        ,delegate() {
                        Console.WriteLine("2)");
                        var customers = from c in list
                                        where c.Login == "braun79@mail.ru" || c.Name == "dubif02@mail.ru" || c.Name == "bibib74@mail.ru"
                                        orderby c.Name
                                        select c;
                        DrawResults(customers);
                    },
        delegate () {
                        Console.WriteLine("3)");
                        var customers = from c in list
                                        where (c.Name == "браунулиус" || c.Name == "ангубуес" || c.Name == "ефринулиус" ||
                                        c.Login == "braun79@mail.ru" || c.Name == "dubif02@mail.ru" || c.Name == "bibib74@mail.ru")
                                        && c.Salary > 300
                                        orderby c.Name
                                        select c;
                        DrawResults(customers);
                    },
        delegate () {
                        Console.WriteLine("4)");
                        var customers = from c in list
                                        where c.Salary >= 100 && c.Salary <= 1000
                                        orderby c.Salary
                                        select c;
                        DrawResults(customers);
                    },
        delegate (){
                        Console.WriteLine("5)");
                        var select = (from std in list
                                      orderby std.Salary
                                      select std.Salary).Distinct().ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("6)");
                        var select = (from std in list
                                      orderby std.Age
                                      select std.Age).Distinct().ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("7)");
                        var select = (from std in list
                                      select std.Salary).Min();
                       Console.WriteLine("Min: "+select);
                    },
        delegate (){
                        Console.WriteLine("8)");
                        var select = (from std in list
                                      select std.Salary).Max();
                       Console.WriteLine("Max: "+select);
                    },
        delegate (){
                        Console.WriteLine("9)");
                        var select = (from std in list
                                      select std.Salary).Sum();
                       Console.WriteLine("Sum: "+select);
                    },
        delegate (){
                        Console.WriteLine("10)");
                        var select = (from std in list
                                      where std.Age >=21 &&  std.Age <= 25
                                      select std.Salary).Sum();
                       Console.WriteLine("Sum: "+select);
                    },
        delegate (){
                        Console.WriteLine("11)");
                        var select = (from std in list
                                      select std.Salary).ToList();
                       Console.WriteLine("Medium $: "+select.Sum()/select.Count());
                    },
        delegate (){
                        Console.WriteLine("12)");
                        var select = (from std in list
                                      select std.Age).ToList();
                       Console.WriteLine("Medium $: "+select.Sum()/select.Count());
                    },
        delegate (){
                        Console.WriteLine("13)");
                        var select = (from std in list
                                      where std.Date > DateTime.Now
                                      select std).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("14)");
                    },
        delegate (){
                        Console.WriteLine("15)");
                    },
        delegate (){
                        Console.WriteLine("16)");
                    },
        delegate (){
                        Console.WriteLine("17)");
                        var select = (from c in list
                                      where c.Date.Month == 3
                                      select c).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("18)");
                        var select = (from c in list
                                      where c.Date.Day == 3
                                      select c).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("19)");
                        var select = (from c in list
                                      where c.Date.Day == 5 && c.Date.Month == 4
                                      select c).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("20)");
                        int[]  dataList = new int[] {1,7,11,12,15,19,21,29};

                        var select = (from c in list
                                      where Array.Exists(dataList,(x)=>x == c.Date.Day)
                                      select c).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("21)");
                        var select = (from c in list
                                      where c.Date.Day < c.Date.Month
                                      select c).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("22)");

                        List<Worker> data = new List<Worker>();
                        var min = (from c in list
                                      select c.Age).Min();
                        var max = (from c in list
                                      select c.Age).Max();

                        for(int i = min; i <= max; i++)
                        {
                           var select = (from c in list
                                          where c.Age == i
                                      select c).ToList();

                            Worker temp = null;
                            if(select.Count > 0)
                            {
                                temp = select[0];
                                foreach(var item in select)
                                {
                                   if(item.Salary < temp.Salary)
                                        temp = item;
                                }
                                data.Add(temp);
                            }
                           
                        }
                        DrawResults(data);
                    },
        delegate (){
                        Console.WriteLine("23)");
                        Console.WriteLine("В этих вычислениях нет смысла, разброс зарплат слишком большой, нужно округлять");
                    },
        delegate (){
                        Console.WriteLine("24)");

                        var select = (from std in list
                                      select std.Salary).ToList();
                        int medium = select.Sum()/select.Count();

                        var  result = (from std in list
                                      where std.Salary > medium
                                      select std).ToList();
                        DrawResults(result);
                    },
        delegate (){
                        Console.WriteLine("25)");

                        var select = (from std in list
                                      select std.Age).ToList();
                        int medium = select.Sum()/select.Count();
                        medium = medium/2*3;
                        Console.WriteLine("СР возраст: "+medium);

                        var result = (from std in list
                                      where std.Age < medium
                                      select std).ToList();
                        DrawResults(result);
                    },
        delegate (){
                        Console.WriteLine("26)");

                        var min = (from std in list
                                      select std.Salary).Min();

                        var select = (from std in list
                                      where std.Salary == min
                                      select std).ToList();
                        DrawResults(select);
                    },
        delegate (){
                        Console.WriteLine("27)");

                        var max = (from std in list
                                      select std.Salary).Max();

                        var select = (from std in list
                                      where std.Salary == max
                                      select std).ToList();
                        DrawResults(select);
                    }
        };

    }
}
