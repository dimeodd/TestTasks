﻿using System;
using System.Linq;
using System.Reflection;
using NameGeneratores;

namespace testApp_17
{

    class Program
    {
        static void Main(string[] args)
        {

            Console.WindowHeight *= 2;

            /*
            var cfg = new Configuration();

            cfg.Configure();
            var sefact = cfg.BuildSessionFactory();

            using (var session = sefact.OpenSession())
            {
                using (var tx = session.BeginTransaction())
                {
                    var workers = session.CreateCriteria<Worker>().List<Worker>();
                    if (workers.Count < 500)
                    {
                        var values = CreateDataBase(500);
                        WriteData(values);
                    }
                    workers = null;

                    MyTasks.Init(session.CreateCriteria<Worker>().List<Worker>().ToArray());
                   
                    tx.Commit();
                }
            }
            */
            var values = CreateDataBase(500);
            MyTasks.Init(values);

            GC.Collect();


            for (int i = 0; i < MyTasks.Task.Length; i++)
            {
                Console.Clear();
                Console.WriteLine($"Task {i + 1}/{MyTasks.Task.Length}");
                MyTasks.Task[i]();
                Console.WriteLine("Press anykey to continue");
                Console.ReadKey();
            }
            Console.ReadLine();
        }

        static Worker[] CreateDataBase(int size)
        {

            if (size < 1)
                throw new ArgumentException($"{size} can't be less then 1");


            Worker[] NewData = new Worker[size];

            Random rand = new Random((int)DateTime.Now.ToBinary());
            DateTime start = new DateTime(1960, 1, 1);


            for (int i = 0; i < size; i++)
            {
                string name = Translit_EN_to_RU.TStool.ConvertToRu(NameGeneratores.NGtool.GetName());
                DateTime date = start.AddDays(rand.Next(0, (DateTime.Now - start).Days - 365 * 18));
                int soc = rand.Next(0, 4);

                NewData[i] = new Worker
                {
                    Name = name,
                    Date = date,
                    Age = DateTime.Now.Year - date.Year,
                    Login = ToLogin(name, date),
                    Salary = GetSalary(DateTime.Now.Year - date.Year, soc)
                };

                //var wrk = NewData[i];
                //Console.WriteLine("{0}\t{1}\t{2}\t{3} зарплата: {5}",
                //    wrk.Name, wrk.Age, wrk.Login, wrk.Date, soc, wrk.Salary);
            }
            return NewData;

        }


      static  string ToLogin(string a_name, DateTime td)
        {
            return Translit_EN_to_RU.TStool.ConvertToEN(a_name).Substring(0, 5) + td.ToString("yy") + "@mail.ru";
        }

       static int GetSalary(int old, int socialLevel)
        {
            float solarMinimum = 66;

            float[] oldParam = new float[] { 18, 24, 28, 35, 40, 45, 60 };
            float[] indx = new float[] { 1, 1.25f, 1.5f, 2.5f, 3f, 3.5f, 2.5f };

            for (int i = 1; i < oldParam.Length; i++)
            {
                if (oldParam[i] >= old && i != 0)
                {
                    float a = (old - oldParam[i - 1]) / (oldParam[i] - oldParam[i - 1]);
                    float b = indx[i - 1] + (indx[i] - indx[i - 1]) * a;
                    solarMinimum *= b;

                    break;
                }
            }

            switch (socialLevel)
            {
                case 1:
                    solarMinimum *= 1.5f;
                    break;
                case 2:
                    solarMinimum *= 2;

                    break;
                case 3:
                    solarMinimum *= 6;
                    break;
                default:
                    solarMinimum *= 0.5f;
                    break;
            }

            return (int)solarMinimum;
        }
    }
}

