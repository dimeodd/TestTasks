﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2_1
{
  class Program
  {
    static void Main(string[] args)
    {
      int a = ReadInt("insert Min value");
      int b = ReadInt("insert Max value");

      for (int i = 0; i < 3; i++)
      {
        IsInsert(a, b, ReadInt("insert value"), out var text);
        Console.WriteLine(text);
      }

      Console.ReadKey();
    }

    static void IsInsert(int a, int b, int c, out string result)
    {
      if (a < b)
      {
        result = string.Format
          ("A = {0},B = {1},C = {2}, ответ: {3}",
            a,
            b,
            c,
            a <= c  && c <= b ? "ДА" : "НЕТ"
          );
      }
      else
      {
        result = "ошибка ввода данных: A >= B";
      }

    }

    static int ReadInt(string message)
    {
      if (message != null)
        Console.WriteLine(message);

      var text = Console.ReadLine();

      if (int.TryParse(text, out var result))
        return result;
      else
        return ReadInt(message);
    }
  }
}
