﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp2_2
{
  class Program
  {
    static void Main(string[] args)
    {
      var value = ReadNatirInt("Insert natural number");

      Console.WriteLine($"A = {value}, ответ:");
      for(int i = 1; i < value; i++)
      {
        if(i%2 == 0)
          Console.Write(" " + i);
      }

      Console.ReadKey();
    }


    /// <summary>
    /// Return natural number >=0
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    static int ReadNatirInt( string message)
    {
      if (message != null)
        Console.WriteLine(message);

      var text = Console.ReadLine();

      if (int.TryParse(text, out var result) && result >= 0)
        return result;
      else
        return ReadNatirInt(message);
    }
  }
}
