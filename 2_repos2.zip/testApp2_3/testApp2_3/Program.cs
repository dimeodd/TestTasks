﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp2_3
{
  class Program
  {
    static void Main(string[] args)
    {
      int[] array = { 20, 50, -4, 18, 25, -36 };

      int count = 0;

      foreach (var item in array)
      {
        if (item > 0)
        {
          count++;
          Console.Write(" " + item);
        }
      }
      Console.WriteLine("\nCount: " + count);

      Console.ReadKey();
    }
  }
}
