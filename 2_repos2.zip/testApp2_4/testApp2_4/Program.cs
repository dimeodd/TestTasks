﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp2_4
{
  class Program
  {
    static void Main(string[] args)
    {
      Costumer ivan = new Costumer("Иван Плейсхолдер Иванович", new Adress("ул. Никакая 1"));
      Costumer john = new Costumer("John Smit", new Adress("ул. Абсолютная 001"));

      Product[] storage =
      {
        new Product("мышь",       null, new CountOnStorrage(50)),
        new Product("клавиатура", null, new CountOnStorrage(50)),
        new Product("экран",      null, new CountOnStorrage(50)),
        new Product("пк",         null, new CountOnStorrage(50)),
        new Product("гарнитура",  null, new CountOnStorrage(50)),
        new Product("стол",       null, new CountOnStorrage(50))
      };

      Product[] orders =
      {
        new Product("мышь",       ivan, new CountOnStorrage(10)),
        new Product("клавиатура", ivan, new CountOnStorrage(37)),
        new Product("мышь",       john, new CountOnStorrage(10)),
        new Product("клавиатура", john, new CountOnStorrage(20)),
        new Product("стол",       john, null),
      };

      #region количество товара на складе
      Console.WriteLine(" количество товара на складе");
      foreach (var item in storage)
      {
        item.InfoCount();
      }
      Console.WriteLine();
      #endregion

      #region информация о заказах
      Console.WriteLine("информация о заказах");
      foreach (var item in orders)
      {
        item.InfoBuy();
      }
      Console.WriteLine();
      #endregion

      #region сколько останется на складе
      Console.WriteLine("сколько останется на складе после продажи");

      Product[] storageAfterSell = Product.DeepCopy(storage);

      foreach (var item in orders)
      {
        int index = Array.FindIndex(storageAfterSell, (x) => x.Label == item.Label);

        if (item.Storage != null)
          storageAfterSell[index].Storage.Count -= item.Storage.Count;

        Console.WriteLine("Товар:{0}, Количество: {1} шт",
            storageAfterSell[index].Label,
            storageAfterSell[index].Storage.Count
          );
      }
      #endregion

      Console.ReadKey();


    }


  }



  public class Product
  {
    public string Label;
    public Costumer Costumer;
    public CountOnStorrage Storage;

    public Product(string label, Costumer costumer, CountOnStorrage storCount)
    {
      Label = label;
      Costumer = costumer;
      Storage = storCount;
    }

    public void InfoCount()
    {
      if (Storage != null)
      {
        Console.WriteLine(string.Format(
          "{0} - {1} шт",
            Label,
            Storage.Count
          )
        );
      }
    }


    public void InfoBuy()
    {
      if (Costumer != null && Storage != null && Storage.Count > 0)
      {
        Console.WriteLine(string.Format(
         "Товар: {0}, Покупатель: {1}, Адрес: {2}",
           Label,
           Costumer.Name,
           Costumer.Adress.Label
         )
       );

      }

    }
    public static Product[] DeepCopy(Product[] sourceArray)
    {
      Product[] copy = new Product[sourceArray.Length];

      for (int i = 0; i < sourceArray.Length; i++)
      {
        Product item = sourceArray[i];
        copy[i] = new Product(
            item.Label,
            item.Costumer != null ? new Costumer(item.Costumer.Name, item.Costumer.Adress) : null,
            new CountOnStorrage(item.Storage.Count)
          );
      }

      return copy;

    }
  }

  public class CountOnStorrage
  {
    public int Count;

    public CountOnStorrage(int count)
    {
      Count = count;
    }
  }


  public class Costumer
  {
    public string Name;
    public Adress Adress;

    public Costumer(string name, Adress adress)
    {
      Name = name;
      Adress = adress;
    }
  }

  public class Adress
  {
    public string Label;
    public Adress(string label)
    {
      Label = label;
    }
  }


}
