﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            var human1 = new Human("Albert");
            var human2 = new Human("Jon");

            var car1 = new Car("carver");
            var car2 = new Car("baser");
            var car3 = new Car("cruser");
            var car4 = new Car("uoser");
            var car5 = new Car("jouser");

            human1.Cars = new Car[3];
            human1[0] = car1;
            human1[1] = car2;
            human1[2] = car4;

            human2.Cars = new Car[1];
            human2[0] = car5;

            GetCarsInfo(human1);
            GetCarsInfo(human2);

            Console.ReadKey();
        }

        static void GetCarsInfo(Human hum)
        {
            Console.Write(string.Format(
                "Name: {0} - Cars: ",
                hum.Name
                ));

            for (int i = 0; i < hum.Length; i++)
            {
                if (i == hum.Length - 1)
                    Console.Write(hum[i] + "\n");
                else
                    Console.Write(hum[i] + ", ");
            }
        }

    }

    class Human
    {
        public string Name;
        public Car[] Cars;

        public Human(string name)
        {
            Name = name;
        }

        public Car this[int index]
        {
            get
            {
                if (index >= 0 && index < Cars.Length)
                    return Cars[index];
                else
                    throw new NullReferenceException("Out of Array");
            }
            set
            {
                if (index >= 0 && index < Cars.Length)
                    Cars[index] = value;
                else
                    throw new NullReferenceException("Out of Array");
            }
        }

        public int Length => Cars.Length;
    }

    class Car
    {
        public string Label;

        public Car(string label)
        {
            Label = label;
        }

        public override string ToString() => Label;
    }
}
