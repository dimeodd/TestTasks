﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            var human = new Human("Bill");
            var student = new Student("Bill", 7);

            Console.WriteLine(human);
            Console.WriteLine(student);

            Console.ReadKey();
        }
    }


    class Human
    {
        public string Name;

        public Human(string name)
        {
            Name = name;
        }

        public override string ToString() => Name;
    }

    class Student : Human
    {
        public int ClassNumber;

        public Student(string name, int classNum) : base(name)
        {
            ClassNumber = classNum;
        }


        public override string ToString() => string.Format("Name: {0}, Class: {1}",
            base.ToString(),
            ClassNumber
            );
    }
}
