﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            var student1 = new Student("Коля", "8Б");
            var student2 = new Student("Боря", "10А");

            var teacher1 = new Teacher("Ольга", "Николаевна", "Математика");
            var teacher2 = new Teacher("Людмила", "Сергеевна", "Русский язык");

            Console.WriteLine(student1);
            Console.WriteLine(student2);

            Console.WriteLine(teacher1);
            Console.WriteLine(teacher2);

            Console.ReadKey();
        }
    }


    class Human
    {
        public string Name;

        public Human(string name)
        {
            Name = name;
        }

        public override string ToString() => Name;
    }

    class Student : Human
    {
        public string ClassNumber;

        public Student(string name, string classNum) : base(name)
        {
            ClassNumber = classNum;
        }


        public override string ToString() => string.Format("Ученик: {0} {1} класс",
            base.Name,
            ClassNumber
            );
    }
    class Teacher : Human
    {
        public string SecondName;
        public string Lesson;

        public Teacher(string name, string secName, string lesson) : base(name)
        {
            SecondName = secName;
            Lesson = lesson;
        }


        public override string ToString() => string.Format("Учительница: {0} {1} {2}",
            base.Name,
            SecondName,
            Lesson
            );
    }
}