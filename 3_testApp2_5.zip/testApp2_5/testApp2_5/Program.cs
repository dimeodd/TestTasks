﻿using System;

namespace testApp2_5
{
    class Program
    {
        static void Main(string[] args)
        {

            var costumer = new Costumer("Bill");

            var compl1 = new Complectation("trash");
            var compl2 = new Complectation("base");
            var compl3 = new Complectation("advansed");
            var compl4 = new Complectation("ultimate");

            var car1 = new Car("DRANDULETTE", costumer, compl1);
            var car2 = new Car("COREvette", costumer, compl4);
            var car3 = new Car("Advanase", costumer, compl2);
            var car4 = new Car("BASEratty", costumer, compl3);

            Console.WriteLine("Заказ:");
            Console.WriteLine(car1);
            Console.WriteLine(car2);
            Console.WriteLine(car3);
            Console.WriteLine(car4);

            Console.ReadKey();

        }
    }

    class Car: Label
    {
        public Costumer Costumer;
        public Complectation Complectation;

        public Car(string label,Costumer costumer,Complectation compl) : base(label) {
            Costumer = costumer;
            Complectation = compl;
        }

        public override string ToString()
        {
            return string.Format(
                    "Покупатель: {0}, Машина: {1}, Комплектация: {2}",
                    Costumer,
                    LabelName,
                    Complectation
                );
        }

    }

    class Complectation:Label
    {
        public Complectation(string label) : base(label) { }
    }

    class Costumer: Label
    {
        public Costumer(string label) : base(label) { }
    }

    abstract class Label {

        public string LabelName;

        public Label(string label)
        {
            LabelName = label;
        }

        public override string ToString() => LabelName;
    }

}
