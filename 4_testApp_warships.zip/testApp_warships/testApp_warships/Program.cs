﻿using System;
using System.Collections.Generic;

namespace testApp_warships
{
    class Program
    {
        static void Main(string[] args)
        {
            Field field = new Field();

            var gen = new Generator();

            for (int i = 0; i < 3; i++)
            {
                gen.Start(field);
                field.DrawField();
            }

            Console.ReadKey();

        }

        public class Generator
        {
            Random _rand;
            Field _bufferFuild;
            Stack<Ship> _ships;
            Field _field;


            public Generator(int key = 0)
            {
                _rand = key == 0 ? new Random() : new Random(key);
            }

            public void Start(Field field)
            {
                _field = field;
                do
                {
                    _field.Clean();
                    _bufferFuild = new Field();
                    CreateShips();
                } while (!SetShips());


            }


            bool SetShips()
            {
                bool ready = true;


                while (_ships.Count > 0)
                {
                    int tryCounret = 0;

                    var ship = _ships.Pop();

                    ship.IsHorizontal = _rand.Next(2) > 0;

                    do
                    {
                        tryCounret++;
                        ship.Pos = Vector2D.GetRandom(10, 10, ref _rand);

                        if (tryCounret > 100)
                            return false;
                    } while (
                        !_bufferFuild.IsCleanSquare(
                                ship.Pos,
                                ship.IsHorizontal ?
                                    new Vector2D(ship.Size, 1) :
                                    new Vector2D(1, ship.Size)
                                )
                    );

                    _bufferFuild.SetSquare(
                                ship.Pos - new Vector2D(1,1),
                                ship.IsHorizontal ?
                                    new Vector2D(ship.Size+2, 3) :
                                    new Vector2D(3, ship.Size+2)
                                );

                    _field.SetSquare(
                        ship.Pos,
                        ship.IsHorizontal ?
                                    new Vector2D(ship.Size, 1) :
                                    new Vector2D(1, ship.Size));


                }
                return ready;
            }

            void CreateShips()
            {
                _ships = new Stack<Ship>();

                for (int size = 1; size <= 4; size++)
                    for (int count = 1; count <= 5 - size; count++)
                    {
                        var ship = new Ship();
                        ship.Size = size;
                        _ships.Push(ship);
                    }
            }

        }

        public class Field
        {
            public const char Border = '#';
            public const char Ship = '0';

            public const int Height = 10;
            public const int Width = 10;

            bool[,] _data = new bool[Field.Width, Field.Height];

            public void Clean()
            {
                _data = new bool[Field.Width, Field.Height];
            }

            public void SetPoint(int x, int y, bool status)
            {
                if (x >= 0 && y >= 0 && x < Width && y < Height)
                    _data[x, y] = status;
            }

            public bool CheckPoint(Vector2D pos) => CheckPoint(pos.x, pos.y);
            public bool CheckPoint(int x, int y)
            {
                return (x >= 0 && y >= 0 && x < Width && y < Height) ?
                    _data[x, y] :
                    false;
            }

            public void SetSquare(Vector2D pos, Vector2D size)
            {
                Vector2D min = pos;
                Vector2D max = pos + size;

                bool isClean = true;

                for (int x = min.x; x < max.x; x++)
                    for (int y = min.y; y < max.y; y++)
                    {
                        SetPoint(x, y, true);
                    }

            }
            public bool IsCleanSquare(Vector2D pos, Vector2D size)
            {
                Vector2D min = pos;
                Vector2D max = pos + size;

                bool isClean = true;

                for (int x = min.x; x < max.x; x++)
                    for (int y = min.y; y < max.y; y++)
                    {
                        isClean &= !CheckPoint(x, y) & (x >= 0 && y >= 0 && x < Width && y < Height);
                    }

                return isClean;
            }

            public void DrawField()
            {
               // Console.Clear();
                for (int y = 0; y < Height + 2; y++)
                {
                    string text = "";
                    for (int x = 0; x < Width + 2; x++)
                    {
                        if (y == 0 || y == Height + 1 || x == 0 || x == Width + 1)
                            text += Border;
                        else if (_data[x - 1, y - 1])
                            text += Ship;
                        else
                            text += ' ';
                    }
                    Console.WriteLine(text);
                }
            }
        }

        public struct Ship
        {
            public Vector2D Pos;
            public int Size;
            public bool IsHorizontal;
        }

        public struct Vector2D
        {
            public int x;
            public int y;

            public Vector2D(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public static Vector2D GetRandom(int maxX, int maxY, ref Random rand) => GetRandom(new Vector2D(maxX, maxY), ref rand);
            public static Vector2D GetRandom(Vector2D max, ref Random rand)
            {
                Vector2D vec = new Vector2D();

                vec.x = (int)rand.Next(max.x);
                vec.y = (int)rand.Next(max.x);

                return vec;
            }

            public static Vector2D operator +(Vector2D a, Vector2D b)
            {
                Vector2D resuls = new Vector2D();
                resuls.x = a.x + b.x;
                resuls.y = a.y + b.y;
                return resuls;
            }
            public static Vector2D operator -(Vector2D a, Vector2D b)
            {
                return a + b * -1;
            }
            public static Vector2D operator *(Vector2D a, float b)
            {
                Vector2D resuls = new Vector2D();
                resuls.x = (int)(a.x * b);
                resuls.y = (int)(a.y * b);
                return resuls;
            }
        }
    }
}

