﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp1_2
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Input stroke");
      var text = Console.ReadLine().ToCharArray();
      Array.Reverse(text);
      Console.WriteLine(new string(text));

      Console.ReadKey();
    }
  }
}
