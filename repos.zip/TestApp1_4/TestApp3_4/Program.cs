﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3_4
{
  class Program
  {

   static char dot = '#';
    static void Main(string[] args)
    {
      Console.Write("Insert size of square:");
      int size = ConsoleTool.ReadInt(0);
      int max = size - 1;

      string text = null;
      for(int i = 0; i < size; i++)
      {

        Console.WriteLine();

        if (i == 0|| i == size - 1)
        {
          for (int x = 0; x < size; x++)
          {
            Console.Write(dot);
          }
        }
        else
        {
          Console.Write(dot);
          for (int x = 1; x < size-1; x++)
          {
            Console.Write(' ');
          }
          Console.Write(dot);
        }         
      }

      Console.ReadKey();

    }
  }

  static class ConsoleTool
  {
    public static int ReadInt(int min)
    {

      Console.WriteLine($"Input number more or equale then {min}");

      string text = Console.ReadLine();

      if (int.TryParse(text, out var result) & result >= min)
      {
        return result;
      }
      else
      {
        Console.WriteLine($"Value less then {min}");
        return ReadInt(min);
      }
    }

  }
}
