﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp1_1
{
  class Program
  {
   static string[] array = new string[5]
    {
      "один",
      "два",
      "три",
      "четыре",
      "пять"
    };

    static void Main(string[] args)
    {
      Console.WriteLine(array[ConsoleTool.ReadInt(1, 5) - 1]);
      Console.ReadKey();
    }

  static  class ConsoleTool
    {

      public static int ReadInt(int min, int max)
      {
        if(min> max)
        {
          var temp = min;
          min = max;
          max = temp;
        }

        Console.WriteLine($"Input number include in [{min},{max}]");

        string text = Console.ReadLine();

        if(int.TryParse(text, out var result)& result>= min & result<=max)
        {
          return result;
        }
        else
        {
          Console.WriteLine($"Value not include in [{min},{max}]");
          return ReadInt(min, max);
        }
      }

    }

  }
}
