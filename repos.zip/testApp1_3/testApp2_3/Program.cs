﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testApp2_3
{
  class Program
  {
    static List<string> list = new List<string>();
    static void Main(string[] args)
    {
      string value = string.Empty;

      Console.WriteLine("To exit write \"СТОП\"");

      while (true)
      {
        value = Console.ReadLine();
        if (value == "СТОП")
          break;
        else
          list.Add(value);
      }

      if(list.Count > 0)
      {
        value = string.Join(null,list);
        Console.WriteLine(value);
      }
      Console.ReadKey();
    }
  }
}
